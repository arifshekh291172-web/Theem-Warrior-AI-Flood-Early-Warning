# NE-SHIELD
### AI-Powered Landslide Early Warning & Real-Time Disaster Monitoring System
**Focused on the North Eastern Region of India (Assam, Arunachal Pradesh, Manipur, Meghalaya, Mizoram, Nagaland, Sikkim, Tripura)**

---

## 1. System Overview

**NE-SHIELD** is an operational, production-style disaster intelligence platform designed specifically for the complex geo-environmental terrain of North Eastern India. The system unites official government feeds (India Meteorological Department, ISRO/NRSC Bhuvan, and NDMA/SACHET) with a custom geotechnical Machine Learning Landslide Risk Prediction Engine, an interactive GIS Command Center, road network connectivity monitors, and offline-first citizen & field operations logging.

### Core Tenets & Anti-Fake Data Policy:
1. **Strict Provenance & Timestamps**: Every dashboard card, weather metric, and rainfall reading explicitly displays its authoritative source (e.g. `Source: IMD`, `Source: ISRO Bhuvan`, `Source: NE-SHIELD ML Engine`) with exact observed and received timestamps in Indian Standard Time (IST).
2. **Explicit Separation of Predictions and Government Bulletins**: Official NDMA/IMD bulletins are strictly demarcated from internal NE-SHIELD ML model risk probabilities.
3. **No Fabricated Numbers**: In `LIVE MODE`, if an external government API is unconfigured or unreachable, the system displays `"NO CURRENT OBSERVATION AVAILABLE"` or `"DATA SOURCE NOT CONFIGURED"` rather than generating synthetic data.
4. **Dual Operational Modes**: Prominent `[LIVE MODE]` and `[DEMO MODE]` toggle in the top command bar.

---

## 2. Technical Stack

| Layer | Technologies |
|---|---|
| **Backend Framework** | Python 3.11+, FastAPI, Uvicorn, Pydantic v2 |
| **Spatial Database** | PostgreSQL 16 + PostGIS 3.4 (with automatic SQLite spatial compatibility for local dev) |
| **ORM & Migrations** | SQLAlchemy 2.0, Alembic |
| **Caching & Messaging** | Redis 7, In-Memory TTL Cache, FastAPI WebSockets (`/ws/live`) |
| **Scheduling Engine** | APScheduler (8 concurrent real-time ingestion jobs) |
| **Custom AI/ML Engine** | Gradient Boosted Decision Trees, Random Forest, scikit-learn, NumPy |
| **Frontend Dashboard** | Modern Dark Command Center, React 18, TypeScript, Vite, Tailwind CSS, Leaflet GIS, Chart.js, Lucide Icons |
| **DevOps & Containers** | Docker, Docker Compose, Multi-stage Nginx |

---

## 3. High-Level Architecture

```mermaid
flowchart TD
    subgraph ExternalSources["Official Government & Sensor Feeds"]
        IMD["IMD API Platform (api.imd.gov.in)
        Weather, Nowcast, Rainfall, Warnings"]
        BHUVAN["ISRO / NRSC Bhuvan
        Terrain, WMS, Landslide Catalog"]
        NDMA["NDMA / SACHET
        CAP Machine-Readable Alerts"]
        IOT["Field IoT Sensors
        Pore Pressure, Rain Gauge, Inclinometer"]
    end

    subgraph Backend["FastAPI Core Backend (Python 3.11+)"]
        ADAPTERS["Integration Adapters
        (IMD, Bhuvan, NDMA)
        Circuit Breaker, Caching, Retry"]
        SCHEDULER["APScheduler / Ingestion Workers
        8 Periodic Jobs"]
        ML_ENGINE["Custom ML Risk Engine
        Feature Engineering (Rainfall, Slope, Moisture)
        XGBoost / GradientBoosted Trees"]
        ALERTS["Alert & Notification Engine
        Role-based Routing, WebSocket Broadcaster"]
        GIS["GIS & Spatial Engine
        GeoJSON, Buffers, Bounding Boxes"]
        REST_API["FastAPI REST & WebSocket Endpoints
        JWT Auth, RBAC, Rate Limiting"]
    end

    subgraph Database["Normalized Spatial Database (PostGIS / PostgreSQL)"]
        DB[(PostgreSQL + PostGIS
        24 Normalized Tables:
        weather, rainfall, terrain,
        predictions, reports, roads,
        data_sources, audit_logs)]
    end

    subgraph Frontend["Command Center UI (React + TypeScript + Vite)"]
        UI_MAIN["Executive Command Center (/dashboard)"]
        UI_MAP["Operational GIS Map (/live-map)"]
        UI_RISK["Risk Analytics & Thresholds (/risk-analysis)"]
        UI_WX["IMD Weather & Rainfall (/weather, /rainfall)"]
        UI_ALERTS["Official Government Warnings (/alerts)"]
        UI_REPORTS["Citizen & Field Officer (/reports, /field)"]
        UI_ROADS["Road Connectivity Network (/roads)"]
        UI_ML["ML Training & Audit (/ml-model, /audit-logs)"]
    end

    IMD --> ADAPTERS
    BHUVAN --> ADAPTERS
    NDMA --> ADAPTERS
    IOT --> ADAPTERS

    ADAPTERS --> SCHEDULER
    SCHEDULER --> DB
    SCHEDULER --> ML_ENGINE
    ML_ENGINE --> DB
    ML_ENGINE --> ALERTS
    ALERTS --> REST_API

    DB <--> REST_API
    REST_API <--> Frontend
    GIS <--> REST_API
```

---

## 4. Database Schema (24 Normalized Tables)

The system creates 24 normalized tables with UUID primary keys and spatial indexes:
1. `roles`: Role definitions (ADMIN, DISTRICT_AUTHORITY, FIELD_OFFICER, ANALYST, CITIZEN)
2. `users`: System users with hashed passwords, roles, department, jurisdiction
3. `states`: The 8 North Eastern states with centroids and boundary definitions
4. `districts`: Monitored administrative districts
5. `locations`: Monitored hazard spots with latitude, longitude, slope, elevation, geology
6. `weather_observations`: Station observations with temperature, humidity, wind, condition, source, provenance
7. `rainfall_observations`: 1h, 3h, 6h, 24h, 72h accumulated precipitation with IMD status
8. `sensor_readings`: In-situ IoT slope telemetry (Pore Pressure, Soil Moisture, Tilt)
9. `terrain_features`: Geotechnical parameters (slope, aspect, curvature, lithology, distance to faults)
10. `historical_landslides`: Verified historical catalog from GSI / Bhuvan
11. `risk_predictions`: Immutable historical record of ML inference runs
12. `risk_zones`: Dynamic spatial polygon buffers around critical escarpments
13. `government_alerts`: Official CAP alerts from IMD and NDMA/SACHET
14. `citizen_reports`: Crowdsourced incident reports with GPS coordinates, media, and status
15. `field_reports`: Field officer ground truth inspections and clearance tracking
16. `media_files`: Uploaded photo/video metadata and SHA-256 hashes
17. `road_segments`: Mountain highways and corridors (NH-27, NH-13, NH-6, NH-29, JN-Road)
18. `road_status`: Current status (OPEN, PARTIALLY_BLOCKED, BLOCKED) with source attribution
19. `notifications`: Alert history sent to dashboard, push, email, SMS
20. `data_sources`: Health and provenance registry for all external integrations
21. `api_logs`: Request latency, endpoints, status codes, caller IPs
22. `model_versions`: Model metadata, algorithm, dataset metrics (confusion matrix, ROC-AUC)
23. `model_predictions`: Audit log of ML inference events
24. `audit_logs`: Administrative actions trace

---

## 5. Quick Start & Local Execution

### Prerequisites
- Python 3.11+
- Git

### 1. Clone & Configure Environment
```powershell
cp .env.example .env
```

### 2. Install Dependencies & Seed Database
```powershell
pip install -r backend/requirements.txt
python -m backend.app.services.seed_data
```

### 3. Train Active ML Model
```powershell
python -m backend.app.ml.train
```

### 4. Run Backend & Command Center
```powershell
uvicorn backend.app.main:app --host 0.0.0.0 --port 8000 --reload
```

- **Interactive Command Center**: [http://localhost:8000/static/index.html](http://localhost:8000/static/index.html) (or [http://localhost:8000/](http://localhost:8000/))
- **Interactive Swagger Docs**: [http://localhost:8000/docs](http://localhost:8000/docs)
- **API Health Check**: [http://localhost:8000/api/health](http://localhost:8000/api/health)

---

## 6. Docker Deployment

To launch the full production stack with PostgreSQL 16 + PostGIS 3.4 and Redis 7:

```bash
docker compose up --build -d
```

Services:
- **Backend API**: `http://localhost:8000`
- **Swagger Documentation**: `http://localhost:8000/docs`
- **Frontend Dashboard**: `http://localhost:5173`
- **PostGIS Spatial Database**: `localhost:5432`
- **Redis Cache**: `localhost:6379`

---

## 7. Official Government Integrations Setup

### India Meteorological Department (IMD)
1. **Portal**: Register at [https://api.imd.gov.in/public/index.php](https://api.imd.gov.in/public/index.php) using an official government or organizational email.
2. **Static IP Whitelisting**: IMD requires whitelisting your server's static public IPv4 address.
3. **API Key**: Retrieve your API key and configure in `.env`:
   ```env
   IMD_API_BASE_URL=https://api.imd.gov.in/api/v1
   IMD_API_KEY=your_registered_imd_api_key
   IMD_CLIENT_ID=your_registered_client_id
   ```

### ISRO / NRSC Bhuvan
1. **Portal**: [https://bhuvan-app1.nrsc.gov.in/disaster/disaster.php](https://bhuvan-app1.nrsc.gov.in/disaster/disaster.php)
2. **WMS Base Maps**: Configure WMS endpoints in `.env`:
   ```env
   BHUVAN_WMS_URL=https://bhuvan-vec1.nrsc.gov.in/bhuvan/wms
   ```

### NDMA / SACHET
1. **Portal**: [https://sachet.ndma.gov.in/](https://sachet.ndma.gov.in/)
2. **CAP Machine-Readable Feed**: Configure feed URL in `.env`:
   ```env
   NDMA_CAP_FEED_URL=https://sachet.ndma.gov.in/cap_feed/rss
   ```

---

## 8. Default Personas & Credentials

For immediate role-based evaluation, pre-seeded accounts are provided:

| Role | Email | Password | Department / Jurisdiction |
|---|---|---|---|
| **Admin** | `admin@ne-shield.gov.in` | `Admin@123` | National Disaster Management Center |
| **District Authority** | `authority@asema.gov.in` | `Authority@123` | ASDMA / DEOC (Assam) |
| **Field Officer** | `officer@pwd.gov.in` | `Officer@123` | Border Roads Organisation / PWD (Arunachal) |
| **Analyst** | `analyst@gsi.gov.in` | `Analyst@123` | Geological Survey of India (NER) |
| **Citizen** | `citizen@ne-shield.org` | `Citizen@123` | Citizen Volunteer (Manipur) |

---

## 9. Automated Testing

Run the full pytest suite (covering database models, IMD parser, ML feature extraction, metrics, and API endpoints):

```powershell
python -m pytest backend/tests -v
```

Output:
```
backend/tests/test_alert_rules.py PASSED
backend/tests/test_api_endpoints.py PASSED
backend/tests/test_database.py PASSED
backend/tests/test_imd_parser.py PASSED
backend/tests/test_ml_pipeline.py PASSED
======================= 23 passed in 2.51s ========================
```
