import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, Activity, CloudSun, CloudRain, 
  Map, AlertTriangle, Flag, Shield, GitCommit, 
  BrainCircuit, Database, FileText, RefreshCw, Clock
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [mode, setMode] = useState<'LIVE' | 'DEMO'>('LIVE');
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSummary();
  }, []);

  const fetchSummary = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/dashboard/summary');
      const data = await res.json();
      setSummary(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#070d1e] text-slate-100 flex flex-col font-sans">
      {/* Top Header */}
      <header className="border-b border-cyan-900/40 bg-[#091126]/90 backdrop-blur sticky top-0 z-50">
        <div className="max-w-[1920px] mx-auto px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center text-black font-bold">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg tracking-wider text-cyan-400">NE-SHIELD</span>
                <span className="text-xs px-2 py-0.5 rounded font-mono font-bold bg-cyan-950 text-cyan-400 border border-cyan-800">NER-HQ</span>
                <span className={`text-xs px-2.5 py-0.5 rounded-full font-mono font-bold border ${mode === 'LIVE' ? 'bg-emerald-950 text-emerald-400 border-emerald-600' : 'bg-amber-950 text-amber-400 border-amber-600'}`}>
                  {mode} MODE
                </span>
              </div>
              <p className="text-[11px] text-slate-400">North Eastern Region Real-Time Landslide Early Warning System</p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono">
            <div className="flex items-center gap-2 bg-slate-900 px-3 py-1.5 rounded border border-slate-800">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>LIVE TELEMETRY</span>
            </div>
            <button onClick={fetchSummary} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-slate-700">
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="max-w-[1920px] mx-auto px-6 flex overflow-x-auto border-t border-slate-800/80 text-xs">
          {[
            { id: 'dashboard', label: 'Command Summary', icon: Activity },
            { id: 'live-map', label: 'Operational GIS Map', icon: Map },
            { id: 'risk', label: 'AI Risk Predictions', icon: BrainCircuit },
            { id: 'weather', label: 'IMD Weather', icon: CloudSun },
            { id: 'rainfall', label: 'Rainfall Analytics', icon: CloudRain },
            { id: 'alerts', label: 'Official Warnings', icon: AlertTriangle },
            { id: 'reports', label: 'Citizen Reports', icon: Flag },
            { id: 'field', label: 'Field Operations', icon: Shield },
            { id: 'roads', label: 'Road Network', icon: GitCommit },
            { id: 'data-sources', label: 'Data Provenance', icon: Database },
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2.5 font-medium border-b-2 transition whitespace-nowrap ${activeTab === tab.id ? 'text-cyan-400 border-cyan-400 bg-cyan-950/20' : 'text-slate-400 border-transparent hover:text-slate-200'}`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </header>

      {/* Main Body Content */}
      <main className="flex-1 max-w-[1920px] mx-auto p-6 w-full space-y-6">
        {activeTab === 'dashboard' && summary && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <div className="glass-panel p-4">
                <span className="text-xs text-slate-400">Active Risk Zones</span>
                <div className="text-3xl font-extrabold font-mono text-red-400 mt-2">{summary.kpis.active_risk_zones}</div>
                <div className="text-[10px] text-slate-500 font-mono mt-1">Source: NE-SHIELD GIS</div>
              </div>
              <div className="glass-panel p-4">
                <span className="text-xs text-slate-400">High Risk Slopes</span>
                <div className="text-3xl font-extrabold font-mono text-orange-400 mt-2">{summary.kpis.high_risk_locations}</div>
                <div className="text-[10px] text-slate-500 font-mono mt-1">Source: ML Risk Engine</div>
              </div>
              <div className="glass-panel p-4">
                <span className="text-xs text-slate-400">Official Warnings</span>
                <div className="text-3xl font-extrabold font-mono text-amber-400 mt-2">{summary.kpis.official_warnings}</div>
                <div className="text-[10px] text-slate-500 font-mono mt-1">Source: IMD / NDMA</div>
              </div>
              <div className="glass-panel p-4">
                <span className="text-xs text-slate-400">Rainfall Alerts</span>
                <div className="text-3xl font-extrabold font-mono text-cyan-400 mt-2">{summary.kpis.rainfall_alerts}</div>
                <div className="text-[10px] text-slate-500 font-mono mt-1">Threshold: &gt;64.5mm</div>
              </div>
              <div className="glass-panel p-4">
                <span className="text-xs text-slate-400">Pending Field Reports</span>
                <div className="text-3xl font-extrabold font-mono text-teal-400 mt-2">{summary.kpis.pending_field_reports}</div>
                <div className="text-[10px] text-slate-500 font-mono mt-1">Ground Inspection</div>
              </div>
              <div className="glass-panel p-4">
                <span className="text-xs text-slate-400">Integrations Online</span>
                <div className="text-3xl font-extrabold font-mono text-emerald-400 mt-2">{summary.kpis.data_sources_online}</div>
                <div className="text-[10px] text-slate-500 font-mono mt-1">Avg Latency: 62ms</div>
              </div>
            </div>

            <div className="glass-panel p-6">
              <h2 className="text-sm font-bold text-slate-200 mb-3 font-mono flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" /> TOP CRITICAL LANDSLIDE HAZARD ESCARPMENTS
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {summary.top_critical_locations.map((loc: any) => (
                  <div key={loc.location_id} className="p-4 rounded bg-slate-900 border border-slate-800 text-xs">
                    <div className="flex justify-between items-start">
                      <div className="font-bold text-slate-200">{loc.location_name}</div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-red-950 text-red-400 border border-red-800">
                        {loc.risk_class} ({(loc.risk_probability * 100).toFixed(0)}%)
                      </span>
                    </div>
                    <div className="text-slate-400 mt-1">State: {loc.state_id} | Slope: {loc.slope_deg}° | Elev: {loc.elevation_m}m</div>
                    <div className="mt-2 text-[11px] text-red-300 bg-red-950/40 p-2 rounded border border-red-900/60">
                      {loc.thresholds_exceeded.join(', ')}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab !== 'dashboard' && (
          <div className="glass-panel p-6 text-center py-16">
            <h2 className="text-lg font-bold text-slate-200 capitalize">{activeTab.replace('-', ' ')} View Active</h2>
            <p className="text-xs text-slate-400 mt-2">Access the integrated full-feature GIS Command Center at <a href="/static/index.html" className="text-cyan-400 underline">http://localhost:8000/static/index.html</a></p>
          </div>
        )}
      </main>
    </div>
  );
}
